#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM 5

int validarCadena(char[], int);
void mostrarPersonas(char[][20], int[], int[], char[], int);
void ordenarPersonas(char[][20], int[], int[], char[], int);
void mostrarPersona(char[], int, int, char);

int main()
{
/*
    char aux[50];
    char mat[5][20];
    char sexo[TAM];
    int id[TAM];
    int edad[TAM];

        for(int i=0; i<TAM; i++){
              printf("Ingrese un nombre: ");
              gets(aux);

              while( !validarCadena(aux, 20) ){
                 printf("Error. Nombre demasiado largo. Reingrese: ");
                gets(aux);
              }
              strcpy(mat[i], aux);

              printf("\nIngrese id: ");
              scanf("%d", &id[i]);

              printf("\nIngrese edad: ");
              scanf("%d", &edad[i]);

              printf("\nIngrese sexo: ");
              scanf("%c", &sexo[i]);

        }
        */
    char aux[50];
    char mat[][20] = {"Juan", "Alicia", "Alberto", "Luis", "Jorge"};
    char sexo[]= {'m', 'f', 'm','m', 'm'};
    int id[] = {123, 873, 567, 198, 202};
    int edad[] = {37, 24, 21, 56, 48};

    mostrarPersonas(mat, id, edad, sexo, TAM);
    printf("\n\n");

    ordenarPersonas(mat, id, edad, sexo, TAM);

      mostrarPersonas(mat, id, edad, sexo, TAM);
    printf("\n\n");

    return 0;
}

int validarCadena(char cadena[], int tam){

    int esValido = 0;

    if(strlen(cadena) < tam){
        esValido = 1;
    }

    return esValido;
}

void mostrarPersonas(char nombres[][20], int ids[], int edades[], char sexos[], int cant){


   for(int i=0; i< cant; i++){

      mostrarPersona(nombres[i], ids[i], edades[i], sexos[i]);
   }

}

void mostrarPersona(char nombre[], int id, int edad, char sexo){

    printf("\n%d %s  %c  %d", id, nombre, sexo, edad);
}

void ordenarPersonas(char mat[][20], int ids[], int edades[], char sexos[], int tam){

    char auxCad[20];
    char auxChar;
    char auxInt;

 for(int i=0; i< tam-1; i++){
        for(int j= i+1; j<tam; j++){
            if(strcmp(mat[i], mat[j])>0){

                strcpy(auxCad, mat[i]);
                strcpy(mat[i], mat[j]);
                strcpy(mat[j], auxCad);

                auxChar = sexos[i];
                sexos[i]= sexos[j];
                sexos[j]= auxChar;

                  auxInt = edades[i];
                edades[i]= edades[j];
                edades[j]= auxInt;

                auxInt = ids[i];
                ids[i]= ids[j];
                ids[j]= auxInt;


            }

        }
    }



}

